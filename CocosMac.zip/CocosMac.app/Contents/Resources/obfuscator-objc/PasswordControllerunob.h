//
//  PasswordController.m
//  ConnectionControl
//
//  Created by Stefan Heim on 14.04.21.
//

#import "PasswordController.h"
#import "FWTObfuscator.h"


@interface PasswordController ()
@property (weak) IBOutlet NSTextField *label;
@property (weak) IBOutlet NSTextField *edit;
@property (weak) IBOutlet NSTextField *result;


@end

@implementation PasswordController

-(id)init {
    self = [super initWithWindowNibName:@"PasswordController"];

    
  
    return self;
}

 static NSString *pass=@"/svIWGUGAWclTYEUYTIeGA==-BjM3OVknuL3917mIivOuMw==-MTY3NjM3NTU3Mg==";
- (IBAction)click5:(id)sender {
    NSLog(@"Down");
        
    if ([_edit.stringValue  isEqual: pass])
    {
        _result.stringValue = @"richtiges Passwort";
    }
    else{
        _result.stringValue = @"falsches Passwort";
    }
}


@end

@end



@end

@end
