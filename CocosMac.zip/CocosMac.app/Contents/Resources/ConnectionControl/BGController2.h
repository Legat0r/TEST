//
//  BGController2.h
//  testbg
//
//  Created by Stefan Heim on 12.03.21.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface BGController2 : NSWindowController

@end

NS_ASSUME_NONNULL_END
