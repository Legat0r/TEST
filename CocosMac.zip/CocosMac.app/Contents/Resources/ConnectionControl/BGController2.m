//
//  BGController2.m
//  testbg
//
//  Created by Stefan Heim on 12.03.21.
//

#import "BGController2.h"

@interface BGController2 ()

@end

@implementation BGController2


-(id)init {
    self = [super initWithWindowNibName:@"BGController2"];

    
   
    return self;
}
@end
