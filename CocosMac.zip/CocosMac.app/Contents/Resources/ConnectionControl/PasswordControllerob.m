//
//  PasswordController.m
//  ConnectionControl
//
//  Created by Stefan Heim on 14.04.21.
//

#import "PasswordController.h"
#import "NSString+FWTObfuscation.h"

@interface PasswordController ()
@property (weak) IBOutlet NSTextField *label;
@property (weak) IBOutlet NSTextField *edit;
@property (weak) IBOutlet NSTextField *result;



@end

@implementation PasswordController

-(id)init {
    self = [super initWithWindowNibName:@"PasswordController"];

    
  
    return self;
}

static NSString * const Pass =  @"CDSBV79wEs3j3tm9SboGmg==-IsigGcCWtL+vgMWZBPftnQ==-MTY3NDkyODA3Ng==";


- (IBAction)click5:(id)sender {
    NSString *test =[Pass unobfuscatedString] ;
     NSLog(@"Down");
     if ([_edit.stringValue  isEqual: test])
     {
         _result.stringValue = @"richtiges Passwort";
     }
     else{
         _result.stringValue = @"falsches Passwort";
     }
}

  



@end
