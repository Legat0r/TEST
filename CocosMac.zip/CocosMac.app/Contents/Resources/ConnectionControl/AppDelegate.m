//
//  AppDelegate.m
//  testbg
//
//  Created by Stefan Heim on 12.03.21.
//

#import "AppDelegate.h"
#import "BGController.h"
#import "BGController2.h"
#import "Demo.h"
#import "PasswordController.h"
#import "Reachability.h"
#import "FWTObfuscator.h"
#import <CoreBluetooth/CoreBluetooth.h>
#import "AESCrypt.h"


#import <SystemConfiguration/SystemConfiguration.h>

#import <UserNotifications/UserNotifications.h>

//Class.m





bool isGrantedNotificationAccess;
bool isClose;
@interface AppDelegate ()

@property (strong) IBOutlet NSWindow *window;

@property (nonatomic, strong) Reachability *reachability;


@property (strong, nonatomic) CBCentralManager *bluetoothManager;


@end



@implementation AppDelegate

- (IBAction)click:(id)sender {
    
    [ self showWindow2:nil];
    
}






- (void)redirectLogToDocuments
{

     NSArray *allPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
     NSString *documentsDirectory = [allPaths objectAtIndex:0];
     NSString *pathForLog = [documentsDirectory stringByAppendingPathComponent:@"cocosLog.txt"];

     freopen([pathForLog cStringUsingEncoding:NSASCIIStringEncoding],"a+",stderr);
}



-(void)userNotificationCenter: (UNUserNotificationCenter *)center willPresentNotification: (UNNotification *)notification withCompletionHandler:(nonnull void (^)(UNNotificationPresentationOptions))completionHandler{
    
    UNNotificationPresentationOptions presentationOptions = UNNotificationPresentationOptionSound;// + UNNotificationPresentationOptionList;
    completionHandler(presentationOptions);
}

- (void)appendLine:(NSString*)line {
    NSString *password=@"1d4234f54fjzd8(ssdalk)93049";
    NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    // or @"yyyy-MM-dd hh:mm:ss a" if you prefer the time with AM/PM
     NSString *datestr=[dateFormatter stringFromDate:[NSDate date]];
    NSString *combstr=[datestr stringByAppendingString:line];
    NSString *encryptedData = [AESCrypt encrypt:combstr password:password];
    NSArray *allPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [allPaths objectAtIndex:0];
    NSString *pathForLog = [documentsDirectory stringByAppendingPathComponent:@"cocosLoglbl.txt"];
    
    NSString *newline = [NSString stringWithFormat:@"%@\r\n", encryptedData];
    
    NSFileHandle *fileHandle = [NSFileHandle fileHandleForWritingAtPath:pathForLog];
    [fileHandle seekToEndOfFile];
    [fileHandle writeData:[newline dataUsingEncoding:NSUTF8StringEncoding]];
    [fileHandle closeFile];

}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
   
   
    
    [[FWTObfuscator defaultObfuscator] setEncryptionKey:@"EKlasse"];
    [self redirectLogToDocuments];
    
   
    
   NSArray *allPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [allPaths objectAtIndex:0];
    NSString *pathForLog = [documentsDirectory stringByAppendingPathComponent:@"cocosLoglbl.txt"];
    
    
    NSFileManager *manager = [NSFileManager defaultManager];
    if (![manager fileExistsAtPath:pathForLog]){
    
    
    NSString *content = @"";
    NSData *fileContents = [content dataUsingEncoding:NSUTF8StringEncoding];
    [[NSFileManager defaultManager] createFileAtPath:pathForLog
                                    contents:fileContents
                                attributes:nil];
    }
    
    
    
    
    
    
    
    if(!self.bluetoothManager)
    {
        if (@available(macOS 10.13, *)) {
            //NSDictionary *options = @{CBCentralManagerOptionShowPowerAlertKey: @NO};
            
            // self.bluetoothManager = [[CBCentralManager alloc] initWithDelegate:self //queue:dispatch_get_main_queue()] ;
            /*
             [self.bluetoothManager scanForPeripheralsWithServices:nil options:@{CBCentralManagerScanOptionAllowDuplicatesKey: @NO}];*/
            self.bluetoothManager = [[CBCentralManager alloc] initWithDelegate:self
                                                                         queue:nil
                                                                       options:
                                     [NSDictionary dictionaryWithObject:[NSNumber numberWithInt:0]
                                                                 forKey:CBCentralManagerOptionShowPowerAlertKey]];  }          // Fallback on earlier versions
        else {        }
    }
    
    
    
    
    self.window.backgroundColor=NSColor.redColor;
    
    isGrantedNotificationAccess=false;
    UNUserNotificationCenter* center = [UNUserNotificationCenter currentNotificationCenter];
    center.delegate= self;
    [center requestAuthorizationWithOptions: UNAuthorizationOptionAlert | UNAuthorizationOptionSound completionHandler:^(BOOL granted, NSError * _Nullable error) {
        NSLog(@"Notifications: %@", granted ? @"<granted>" : @"<not granted>");
        isGrantedNotificationAccess= granted;
    }];
    
    NSDate *today = [NSDate date]; // it will give you current date
    NSString *dateStr = @"20250503";

    // Convert string to date object
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"yyyyMMdd"];
    NSDate *checkdate = [dateFormat dateFromString:dateStr];

    NSComparisonResult result;
    //has three possible values: NSOrderedSame,NSOrderedDescending, NSOrderedAscending

    result = [today compare:checkdate]; // comparing two dates

    isClose=false;
  
    
   
    if(result==NSOrderedAscending)
        NSLog(@"Lizenz gültig!");
    else if(result==NSOrderedDescending){
        NSLog(@"Lizenz ungültig");
        UNMutableNotificationContent *content =[[UNMutableNotificationContent alloc]init];
        NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        // or @"yyyy-MM-dd hh:mm:ss a" if you prefer the time with AM/PM
        NSLog(@"%@",[dateFormatter stringFromDate:[NSDate date]]);
        
        
        
        
        
        
        
        NSString *str = @"Cocos beendet!!!";
        
        content.title=str;
        content.subtitle=@"ConnectionControl";
        content.body= @"Ihre Lizenz ist abgelaufen!";
        content.sound= nil; //[UNNotificationSound nil];
        
        NSURL *imageURL =[[NSBundle mainBundle] URLForResource:@"picture" withExtension: @"png"];
        
        
        NSError *error;
        UNNotificationAttachment *icon = [UNNotificationAttachment attachmentWithIdentifier:@"image" URL:imageURL options:nil error:&error];
        if (error)
        {
            //NSLog(@"error while storing image attachment in notification: %@", error);
        }
        if (icon)
        {
           // NSLog(@"ispic");
            content.attachments = @[icon];
        }
        
        UNTimeIntervalNotificationTrigger *trigger = [UNTimeIntervalNotificationTrigger triggerWithTimeInterval:1 repeats:NO];
        
        UNNotificationRequest *request = [UNNotificationRequest requestWithIdentifier:@"UYLLocalNotification" content:content trigger:trigger];
        
        [center addNotificationRequest:request withCompletionHandler:nil];
        
        
         isClose=true;
   //     [[NSApplication sharedApplication] terminate:nil];
        
    }
    else
        NSLog(@"Lizenz gültig!");
    //  ViewController* testbox = [[ViewController alloc]init];
    
    //this tells the window to add our subview testbox to it's contentview
    //    [[self.window contentView]addSubview:testbox];
    
    // Override point for customization after application launch.
    
    
}

/*- (void)centralManagerDidUpdateState:(CBCentralManager *)central
 {
 
 
 if (@available(macOS 10.13, *)) {
 if (self.bluetoothManager.state == CBManagerStatePoweredOn ){
 NSLog(@"bluetooth  on");
 } else {
 NSLog(@"bluetooth not on");
 }
 } else {
 // Fallback on earlier versions
 }
 
 
 }*/


- (void)viewDidLoad {
    [self detectBluetooth];
}

- (void)detectBluetooth
{
    if(!self.bluetoothManager)
    {
        
        // Put on main queue so we can call UIAlertView from delegate callbacks.
        self.bluetoothManager = [[CBCentralManager alloc] initWithDelegate:self queue:dispatch_get_main_queue()] ;
    }
    else [self centralManagerDidUpdateState:self.bluetoothManager]; // Show initial state
}

- (void)centralManagerDidUpdateState:(CBCentralManager *)central
{
    NSString *stateString = nil;
    switch(self.bluetoothManager.state)
    {
        case CBCentralManagerStateResetting: stateString = @"The connection with the system service was momentarily lost, update imminent."; break;
        case CBCentralManagerStateUnsupported: stateString = @"The platform doesn't support Bluetooth Low Energy.";
            
           
            break;
        case CBCentralManagerStateUnauthorized: stateString = @"The app is not authorized to use Bluetooth Low Energy."; break;
            
        case CBCentralManagerStatePoweredOff: stateString = @"Bluetooth is currently powered off.";
            
            break;
        case CBCentralManagerStatePoweredOn: stateString = @"Bluetooth is currently powered on and available to use.";
            statebt=5;
           
            [central scanForPeripheralsWithServices:nil options:
                                                                                                                        [NSDictionary dictionaryWithObject:[NSNumber numberWithInt:0]
                                                                                                                                                    forKey:CBCentralManagerOptionShowPowerAlertKey]];
            break;
        default: stateString = @"State unknown, update imminent."; break;
    }
   // NSLog(@"%@", stateString);
    
}

#pragma mark - CBCentralManagerDelegate





-  (NetworkStatus)checkInternetConnection
{
    
    self.reachability = [Reachability reachabilityForInternetConnection];
    // self.reachability = [Reachability reachabilityForLocalWiFi];
    return [self.reachability currentReachabilityStatus];
    
}


-(void) awakeFromNib {
    
    [ self showWindow:nil];
    [ self showWindow1:nil];
    [ self showWindow3:nil];
    
    //
    
    
    
    [NSTimer scheduledTimerWithTimeInterval:4.0
                                     target:self
                                   selector:@selector(timer)
                                   userInfo:nil
                                    repeats:YES];
    
    [self.window setBackgroundColor:[NSColor redColor]];
    
}


int x;
int statebt=0;
int x=0;
int y=0;
int z=0;
int s=0;
bool reachable=false;
-(void)shownotification{
    if (isClose==true)  [[NSApplication sharedApplication] terminate:nil];
    
    switch([self checkInternetConnection]){
        case NotReachable:
            if (self.bluetoothManager.state!=5){
               
                if (reachable==true){
                    s=0;z=0,y=0;
                    reachable=false;
                }
            x=x+1;
            
            if (x>4){
               
               /*
                NSArray *allPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
                NSString *documentsDirectory = [allPaths objectAtIndex:0];
                NSString *pathForLog = [documentsDirectory stringByAppendingPathComponent:@"yourFile1.txt"];
               
                NSString *fileContent =[NSString stringWithContentsOfFile:pathForLog  encoding:NSUTF8StringEncoding error:nil];
                //NSLog(@"fileContent= %@",fileContent);
                
               // NSString *newFileContent=[NSString stringWithFormat:@"fsdfdsffffffffffccdssdgd",fileContent];
               // [newFileContent writeToURL:url atomically:YES encoding:NSUTF8StringEncoding error:nil];
                   
                
               
                
                
                NSString *password = @"p4ssw0rd";
                NSString *encryptedData = [AESCrypt encrypt:fileContent password:password];
                [encryptedData writeToFile:pathForLog atomically:YES encoding:NSUTF8StringEncoding error:nil];*/
                
                
                if (isGrantedNotificationAccess)
                {
                    UNUserNotificationCenter *center =[UNUserNotificationCenter currentNotificationCenter];
                    UNMutableNotificationContent *content =[[UNMutableNotificationContent alloc]init];
                    NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
                    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
                    // or @"yyyy-MM-dd hh:mm:ss a" if you prefer the time with AM/PM
                    NSLog(@"%@",[dateFormatter stringFromDate:[NSDate date]]);
                    
                    
                    
                    
                    
                    
                    NSString *zstr = [NSString stringWithFormat:@"%i", z];
                    NSString *sstr = [NSString stringWithFormat:@"%i", s];
                    NSString *str = @"Offline for ";
                    str = [str stringByAppendingString: zstr];
                    str = [str stringByAppendingString: @" minutes and "];
                    str = [str stringByAppendingString: sstr];
                    str = [str stringByAppendingString: @" seconds"];
                    content.title=str;
                    content.subtitle=@"ConnectionControl";
                    content.body= @"You are currently not connected to the internet!!";
                    content.sound= nil; //[UNNotificationSound nil];
                    
                    NSURL *imageURL =[[NSBundle mainBundle] URLForResource:@"green" withExtension: @"png"];
                    
                    
                    NSError *error;
                    UNNotificationAttachment *icon = [UNNotificationAttachment attachmentWithIdentifier:@"image" URL:imageURL options:nil error:&error];
                    if (error)
                    {
                        //NSLog(@"error while storing image attachment in notification: %@", error);
                    }
                    if (icon)
                    {
                       // NSLog(@"ispic");
                        content.attachments = @[icon];
                    }
                    
                    UNTimeIntervalNotificationTrigger *trigger = [UNTimeIntervalNotificationTrigger triggerWithTimeInterval:1 repeats:NO];
                    
                    UNNotificationRequest *request = [UNNotificationRequest requestWithIdentifier:@"UYLLocalNotification" content:content trigger:trigger];
                    
                    [center addNotificationRequest:request withCompletionHandler:nil];
                    
                    
                }
                x=0;
            
            }
            
            NSLog(@"!!!!!!Offline!!!!!!!!!");
                [self appendLine:@"!!!!!!!!!!Offline!!!!!!!!!!!!!!"];
            [self.window setLevel: NSStatusWindowLevel];
            [bgController.window setLevel: NSStatusWindowLevel];
            [bgController2.window setLevel: NSStatusWindowLevel];
            self.window.backgroundColor = [NSColor greenColor];
            bgController.window.backgroundColor = [NSColor greenColor];
            bgController2.window.backgroundColor = [NSColor greenColor];
            }else{
                reachable=true;
                NSLog(@"-----------Online--------------");
                [self appendLine:@"------------Online---------------"];
                
                if (isGrantedNotificationAccess)
                {
                    UNUserNotificationCenter *center =[UNUserNotificationCenter currentNotificationCenter];
                    UNMutableNotificationContent *content =[[UNMutableNotificationContent alloc]init];
                    
                    content.title=@"ConnectionControl";
                    NSString *zstr = [NSString stringWithFormat:@"%i", z];
                    NSString *sstr = [NSString stringWithFormat:@"%i", s];
                    NSString *str = @"Connect check running for ";
                    str = [str stringByAppendingString: zstr];
                    str = [str stringByAppendingString: @" minutes and "];
                    str = [str stringByAppendingString: sstr];
                    str = [str stringByAppendingString: @" seconds"];
                    content.subtitle=@"You are currently connected to the internet!!";
                    //content.body= str;
                    content.sound=[UNNotificationSound defaultSound];
                    NSURL *imageURL =[[NSBundle mainBundle] URLForResource:@"red" withExtension: @"png"];
                    
                    
                    NSError *error;
                    UNNotificationAttachment *icon = [UNNotificationAttachment attachmentWithIdentifier:@"image" URL:imageURL options:nil error:&error];
                    if (error)
                    {
                        //NSLog(@"error while storing image attachment in notification: %@", error);
                    }
                    if (icon)
                    {
                        //NSLog(@"ispic");
                        content.attachments = @[icon];
                    }
                    
                    UNTimeIntervalNotificationTrigger *trigger = [UNTimeIntervalNotificationTrigger triggerWithTimeInterval:1 repeats:NO];
                    
                    UNNotificationRequest *request = [UNNotificationRequest requestWithIdentifier:@"UYLLocalNotification" content:content trigger:trigger];
                    
                    [center addNotificationRequest:request withCompletionHandler:nil];
                    
                }
                
                //[self.window setLevel: NSStatusWindowLevel];
                self.window.backgroundColor = [NSColor redColor];
                [bgController.window setLevel: NSStatusWindowLevel];
                [bgController2.window setLevel: NSStatusWindowLevel];
                bgController.window.backgroundColor = [NSColor redColor];
                bgController2.window.backgroundColor = [NSColor redColor];
                
            }
            break;
            
        case ReachableViaWiFi:
            
            NSLog(@"-----------Online--------------");
            [self appendLine:@"------------Online---------------"];
            reachable=true;
            if (isGrantedNotificationAccess)
            {
                UNUserNotificationCenter *center =[UNUserNotificationCenter currentNotificationCenter];
                UNMutableNotificationContent *content =[[UNMutableNotificationContent alloc]init];
                
                content.title=@"ConnectionControl";
                NSString *zstr = [NSString stringWithFormat:@"%i", z];
                NSString *sstr = [NSString stringWithFormat:@"%i", s];
                NSString *str = @"Connect check running for ";
                str = [str stringByAppendingString: zstr];
                str = [str stringByAppendingString: @" minutes and "];
                str = [str stringByAppendingString: sstr];
                str = [str stringByAppendingString: @" seconds"];
                content.subtitle=@"You are currently connected to the internet!!";
                //content.body= str;
                content.sound=[UNNotificationSound defaultSound];
                NSURL *imageURL =[[NSBundle mainBundle] URLForResource:@"red" withExtension: @"png"];
                
                
                NSError *error;
                UNNotificationAttachment *icon = [UNNotificationAttachment attachmentWithIdentifier:@"image" URL:imageURL options:nil error:&error];
                if (error)
                {
                    //NSLog(@"error while storing image attachment in notification: %@", error);
                }
                if (icon)
                {
                   // NSLog(@"ispic");
                    content.attachments = @[icon];
                }
                
                UNTimeIntervalNotificationTrigger *trigger = [UNTimeIntervalNotificationTrigger triggerWithTimeInterval:1 repeats:NO];
                
                UNNotificationRequest *request = [UNNotificationRequest requestWithIdentifier:@"UYLLocalNotification" content:content trigger:trigger];
                
                [center addNotificationRequest:request withCompletionHandler:nil];
                
            }
            
            //[self.window setLevel: NSStatusWindowLevel];
            self.window.backgroundColor = [NSColor redColor];
            [bgController.window setLevel: NSStatusWindowLevel];
            [bgController2.window setLevel: NSStatusWindowLevel];
            bgController.window.backgroundColor = [NSColor redColor];
            bgController2.window.backgroundColor = [NSColor redColor];
            
            break;
            
        case ReachableViaWWAN:
            reachable=true;
            NSLog(@"-----------Online--------------");
            [self appendLine:@"------------Online---------------"];
            
            if (isGrantedNotificationAccess)
            {
                UNUserNotificationCenter *center =[UNUserNotificationCenter currentNotificationCenter];
                UNMutableNotificationContent *content =[[UNMutableNotificationContent alloc]init];
                
                content.title=@"ConnectionControl";
                NSString *zstr = [NSString stringWithFormat:@"%i", z];
                NSString *sstr = [NSString stringWithFormat:@"%i", s];
                NSString *str = @"Connect check running for ";
                str = [str stringByAppendingString: zstr];
                str = [str stringByAppendingString: @" minutes and "];
                str = [str stringByAppendingString: sstr];
                str = [str stringByAppendingString: @" seconds"];
                content.subtitle=@"You are currently connected to the internet!!";
                //content.body= str;
                content.sound=[UNNotificationSound defaultSound];
                
                NSURL *imageURL =[[NSBundle mainBundle] URLForResource:@"red" withExtension: @"png"];
                
                
                NSError *error;
                UNNotificationAttachment *icon = [UNNotificationAttachment attachmentWithIdentifier:@"image" URL:imageURL options:nil error:&error];
                if (error)
                {
                    //NSLog(@"error while storing image attachment in notification: %@", error);
                }
                if (icon)
                {
                   // NSLog(@"ispic");
                    content.attachments = @[icon];
                }
                
                
                UNTimeIntervalNotificationTrigger *trigger = [UNTimeIntervalNotificationTrigger triggerWithTimeInterval:10 repeats:NO];
                
                UNNotificationRequest *request = [UNNotificationRequest requestWithIdentifier:@"UYLLocalNotification" content:content trigger:trigger];
                
                [center addNotificationRequest:request withCompletionHandler:nil];
                
            }
            
            
            [self.window setLevel: NSStatusWindowLevel];
            [bgController.window setLevel: NSStatusWindowLevel];
            [bgController2.window setLevel: NSStatusWindowLevel];
            self.window.backgroundColor = [NSColor redColor];
            bgController.window.backgroundColor = [NSColor redColor];
            bgController2.window.backgroundColor = [NSColor redColor];
            
                
            break;
            
        default:
            NSLog(@"Status unbekannt");
            [self appendLine:@"Status unbekannt"];
            [self.window setLevel: NSStatusWindowLevel];
            [bgController.window setLevel: NSStatusWindowLevel];
            [bgController2.window setLevel: NSStatusWindowLevel];
            self.window.backgroundColor = [NSColor redColor];
            bgController.window.backgroundColor = [NSColor redColor];
            bgController2.window.backgroundColor = [NSColor redColor];
            break;
            
            
    }
}
-(void)timer{
    
    y=y+4;
    z=y/60;
    s=s+4;
    if (s>59)s=0;
    
   [self shownotification];
  //  [self detectBluetooth];
    
    
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}
- (IBAction)showWindow:(id)sender {
    if (!bgController) {
        bgController= [[BGController alloc] init];
    }
    bgController.window.backgroundColor = [NSColor redColor];
    [bgController showWindow:nil];
    
    
}

- (IBAction)showWindow1:(id)sender {
    if (!bgController2) {
        bgController2= [[BGController2 alloc] init];
    }
    bgController2.window.backgroundColor = [NSColor redColor];
    [bgController2 showWindow:nil];
    
    
}

- (IBAction)showWindow3:(id)sender {
    if (!demo) {
        demo= [[Demo alloc] init];
    }
    //  demo.window.backgroundColor = [NSColor redColor];
   // [demo showWindow:nil];
    
    
}


- (IBAction)showWindow2:(id)sender {
    if (!passwordController) {
        passwordController= [[PasswordController alloc] init];
        
    }
    // passwordController.window.backgroundColor = [NSColor redColor];
    [passwordController showWindow:nil];
    
    
}

@end
