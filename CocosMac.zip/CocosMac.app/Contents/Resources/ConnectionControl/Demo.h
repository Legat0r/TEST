
//
//  Demo.h
//  testbg
//
//  Created by Stefan Heim on 28.01.23.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface Demo : NSWindowController

@end

NS_ASSUME_NONNULL_END
