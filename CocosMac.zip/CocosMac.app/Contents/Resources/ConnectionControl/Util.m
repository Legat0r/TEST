//
//  Util.m
//  ConnectionControl
//
//  Created by Stefan Heim on 12.03.23.
//

#import <Foundation/Foundation.h>
