//
//  PasswordController.m
//  ConnectionControl
//
//  Created by Stefan Heim on 14.04.21.
//

#import "PasswordController.h"
#import "NSString+FWTObfuscation.h"
#include <stdio.h>
#import "AESCrypt.h"


@interface PasswordController ()
@property (weak) IBOutlet NSTextField *label;
@property (weak) IBOutlet NSTextField *edit;
@property (weak) IBOutlet NSTextField *result;
@property (weak) IBOutlet NSTextField *ischecked;


@end

@implementation PasswordController

-(id)init {
    self = [super initWithWindowNibName:@"PasswordController"];

    
  
    return self;
}

 static NSString *pass=@"yPaEYgui9e+M6Tg3c0JhjQ==-uDA7P2vtg6XB+/IYSlYzUw==-MTcwOTQ3MjEwNQ==";

static NSString *pass1=@"yPaEYgui9e+M6Tg3c0JhjQ==-uDA7P2vtg6XB+/IYSlYzUw==-MTcwOTQ3MjEwNQ==";

- (void)viewDidLoad {
   
}
int iscorrect=0;
- (IBAction)clickCheck:(id)sender {
    
    
    NSString *test =[pass unobfuscatedString] ;
    NSString *test1 =[pass1 unobfuscatedString] ;
   
    
    NSLog(@"Passwort validiert");
     if ([_edit.stringValue  isEqual: test] || [_edit.stringValue  isEqual: test1]  )
     {
         _result.stringValue = @"richtiges Passwort";
        iscorrect=1;
         _ischecked.stringValue=@"der Button ist jetzt validiert!!!";
     }
     else{
         _result.stringValue = @"falsches Passwort";
     }
}

- (IBAction)clickShowLog:(id)sender {
    
    NSArray *allPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [allPaths objectAtIndex:0];
   NSString *pathForLog = [documentsDirectory stringByAppendingPathComponent:@"cocosLog.txt"];
   
    NSString *fileContent =[NSString stringWithContentsOfFile:pathForLog  encoding:NSUTF8StringEncoding error:nil];
    
    [self.logtext insertText:fileContent];
   // NSString *newFileContent=[NSString stringWithFormat:@"fsdfdsffffffffffccdssdgd",fileContent];
   // [newFileContent writeToURL:url atomically:YES encoding:NSUTF8StringEncoding error:nil];
       
    
    
    
}
- (IBAction)clickCheckLog:(id)sender {
    if (iscorrect==1){
    NSArray *allPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [allPaths objectAtIndex:0];
   NSString *pathForLog = [documentsDirectory stringByAppendingPathComponent:@"cocosLoglbl.txt"];
    
    char const *path_cstr = [[NSFileManager defaultManager] fileSystemRepresentationWithPath:pathForLog];
    
    FILE *file = fopen(path_cstr, "r");
    // check for NULL
    self.logtext.textStorage.mutableString.string=@"";
    while(!feof(file))
    {
        NSString *line = readLineAsNSString(file);
        NSString *password = @"1d4234f54fjzd8(ssdalk)93049";
        
        NSString *message = [AESCrypt decrypt:line password:password];
        NSString *newline = [NSString stringWithFormat:@"%@\r\n", message];
        [self.logtext insertText:newline];
        
        // do stuff with line; line is autoreleased, so you should NOT release it (unless you also retain it beforehand)
    }
    fclose(file);
        iscorrect=0;
        _ischecked.stringValue=@"";
    }else { _ischecked.stringValue=@"der Button ist nicht validiert!Passwort checken!";
    }
    }




NSString *readLineAsNSString(FILE *file)
{
    char buffer[4096];

    // tune this capacity to your liking -- larger buffer sizes will be faster, but
    // use more memory
    NSMutableString *result = [NSMutableString stringWithCapacity:256];

    // Read up to 4095 non-newline characters, then read and discard the newline
    int charsRead;
    do
    {
        if(fscanf(file, "%4095[^\n]%n%*c", buffer, &charsRead) == 1)
            [result appendFormat:@"%s", buffer];
        else
            break;
    } while(charsRead == 4095);

    return result;
}
@end
