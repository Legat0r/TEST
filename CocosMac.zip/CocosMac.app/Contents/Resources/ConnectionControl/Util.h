//
//  Util.h
//  ConnectionControl
//
//  Created by Stefan Heim on 12.03.23.
//

#ifndef Util_h
#define Util_h

#import <Cocoa/Cocoa.h>
 
@interface Util: NSObject {
}
 
+(void)MessageBox:(char*) header:(char*) message: (unsigned long) message_type;
 
+(void)MessageBox:(NSString *) header:(NSString *) message;
 
@end
#endif /* Util_h */
