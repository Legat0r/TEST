//
//  NSString+FWTObfuscation.h
//  WTObfuscation
//
//  Created by Fabio Gallonetto on 23/01/2014.
//  Copyright (c) 2014 Future Workshops. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (FWTObfuscation)
- (NSString *)unobfuscatedString;
@end
