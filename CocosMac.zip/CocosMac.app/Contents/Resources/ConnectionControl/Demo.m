
//
//  Demo.m
//  testbg
//
//  Created by Stefan Heim on 12.03.21.
//

#import "Demo.h"

@interface Demo ()

@end

@implementation Demo


-(id)init {
    self = [super initWithWindowNibName:@"Demo"];

    
   
    return self;
}
@end
