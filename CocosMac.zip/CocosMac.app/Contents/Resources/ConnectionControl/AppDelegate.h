//
//  AppDelegate.h
//  ConnectionControl
//
//  Created by Stefan Heim on 13.03.21.
//

#import <Cocoa/Cocoa.h>


@class BGController,BGController2,PasswordController,Demo;
@interface AppDelegate : NSObject <NSApplicationDelegate>{
@private

    Demo *demo;
    BGController *bgController;
    BGController2 *bgController2;
    PasswordController *passwordController;

}

-(IBAction)showWindow:(id)sender;
-(IBAction)showWindow1:(id)sender;
-(IBAction)showWindow2:(id)sender;
-(IBAction)showWindow3:(id)sender;
@end
