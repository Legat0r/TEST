//
//  BGController.m
//  testbg
//
//  Created by Stefan Heim on 12.03.21.
//

#import "BGController.h"

@interface BGController ()

@end

@implementation BGController

-(id)init {
    self = [super initWithWindowNibName:@"BGController"];

    
  
    return self;
}



@end
